import { Image, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

export function Brand({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.row}>
      <Image source={require('@/assets/images/icon.png')} style={[styles.logo, compact && styles.logoSmall]} />
      <View>
        <Text style={[styles.name, { color: colors.foreground }, compact && styles.nameSmall]}>Milk Manager</Text>
        {!compact && <Text style={[styles.tagline, { color: colors.mutedForeground }]}>Dairy, made simpler</Text>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 42, height: 42, borderRadius: 13 },
  logoSmall: { width: 30, height: 30, borderRadius: 9 },
  name: { fontSize: 18, fontWeight: '700', letterSpacing: -0.5 },
  nameSmall: { fontSize: 16 },
  tagline: { fontSize: 11, marginTop: 2, letterSpacing: 0.2 },
});