import React from 'react';
import { Feather } from '@expo/vector-icons';
import { FlatList, Modal, Pressable, StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Customer } from '@/lib/milk-store';

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return <View style={styles.sectionRow}><Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>{action && <Pressable onPress={onAction}><Text style={[styles.link, { color: colors.primary }]}>{action}</Text></Pressable>}</View>;
}

export function Button({ label, onPress, tone = 'primary', icon, small = false }: { label: string; onPress: () => void; tone?: 'primary' | 'secondary' | 'danger'; icon?: keyof typeof Feather.glyphMap; small?: boolean }) {
  const colors = useColors();
  const backgroundColor = tone === 'primary' ? colors.primary : tone === 'danger' ? '#FCECEC' : colors.secondary;
  const foreground = tone === 'primary' ? colors.primaryForeground : tone === 'danger' ? colors.destructive : colors.secondaryForeground;
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.button, { backgroundColor }, small && styles.buttonSmall, pressed && styles.pressed]}><>{icon && <Feather name={icon} size={small ? 15 : 17} color={foreground} />}<Text style={[styles.buttonText, { color: foreground }, small && styles.buttonTextSmall]}>{label}</Text></></Pressable>;
}

export function Field({ label, ...props }: TextInputProps & { label: string }) {
  const colors = useColors();
  return <View style={styles.field}><Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text><TextInput placeholderTextColor={colors.mutedForeground} {...props} style={[styles.input, { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card }, props.multiline && styles.multiline]} /></View>;
}

export function CustomerPicker({ label = 'Customer', customers, value, onChange }: { label?: string; customers: Customer[]; value: string; onChange: (customerId: string) => void }) {
  const colors = useColors();
  const [open, setOpen] = React.useState(false);
  const selected = customers.find((customer) => customer.id === value);
  return <View style={styles.field}>
    <Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text>
    <Pressable onPress={() => setOpen(true)} style={[styles.picker, { backgroundColor: colors.card, borderColor: colors.input }]}><Text style={[styles.pickerValue, { color: selected ? colors.foreground : colors.mutedForeground }]}>{selected?.name ?? 'Select a customer'}</Text><Feather name="chevron-down" size={17} color={colors.mutedForeground} /></Pressable>
    <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
      <Pressable style={styles.modalBackdrop} onPress={() => setOpen(false)}>
        <Pressable style={[styles.modalCard, { backgroundColor: colors.card }]} onPress={(event) => event.stopPropagation()}>
          <Text style={[styles.modalTitle, { color: colors.foreground }]}>{label}</Text>
          <FlatList data={customers} keyExtractor={(item) => item.id} renderItem={({ item }) => <Pressable onPress={() => { onChange(item.id); setOpen(false); }} style={[styles.option, { borderBottomColor: colors.border }]}><View style={[styles.optionAvatar, { backgroundColor: item.id === value ? '#E3F1E8' : colors.muted }]}><Text style={[styles.optionInitial, { color: item.id === value ? colors.primary : colors.mutedForeground }]}>{item.name.slice(0, 1)}</Text></View><View style={styles.optionCopy}><Text style={[styles.optionName, { color: colors.foreground }]}>{item.name}</Text><Text style={[styles.optionPhone, { color: colors.mutedForeground }]}>{item.phone} · {item.status}</Text></View>{item.id === value && <Feather name="check" size={18} color={colors.primary} />}</Pressable>} ListEmptyComponent={<Text style={[styles.emptyPicker, { color: colors.mutedForeground }]}>Add a customer first.</Text>} />
          <Button label="Cancel" tone="secondary" small onPress={() => setOpen(false)} />
        </Pressable>
      </Pressable>
    </Modal>
  </View>;
}

export function StatCard({ label, value, detail, tone = 'green' }: { label: string; value: string; detail?: string; tone?: 'green' | 'cream' | 'orange' | 'red' }) {
  const colors = useColors();
  const backgroundColor = tone === 'green' ? '#E3F1E8' : tone === 'cream' ? '#F8EED8' : tone === 'orange' ? '#FFF0DB' : '#FBE4E4';
  const accent = tone === 'green' ? colors.primary : tone === 'cream' ? '#8B671E' : tone === 'orange' ? '#B46A16' : colors.destructive;
  return <View style={[styles.stat, { backgroundColor }]}><Text style={[styles.statLabel, { color: accent }]}>{label}</Text><Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>{detail && <Text style={[styles.statDetail, { color: colors.mutedForeground }]}>{detail}</Text>}</View>;
}

export function EmptyState({ icon, title, text }: { icon: keyof typeof Feather.glyphMap; title: string; text: string }) {
  const colors = useColors();
  return <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name={icon} size={25} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{text}</Text></View>;
}

export const uiStyles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 16 },
  scrollContent: { paddingHorizontal: 16, paddingBottom: 110, width: '100%', maxWidth: 640, alignSelf: 'center' },
  card: { borderRadius: 18, padding: 16, borderWidth: 1 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
});

const styles = StyleSheet.create({
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 15, fontWeight: '700', letterSpacing: -0.2 },
  link: { fontSize: 12, fontWeight: '700' },
  button: { minHeight: 46, borderRadius: 14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  buttonSmall: { minHeight: 38, borderRadius: 12, paddingHorizontal: 12 },
  buttonText: { fontSize: 14, fontWeight: '700' },
  buttonTextSmall: { fontSize: 12 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  field: { gap: 7, marginBottom: 14 },
  label: { fontSize: 12, fontWeight: '600', letterSpacing: 0.2 },
  input: { minHeight: 46, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, fontSize: 14 },
  picker: { minHeight: 46, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pickerValue: { fontSize: 14, flex: 1 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(24,50,41,0.35)', justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18, maxHeight: '72%' },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10 },
  option: { minHeight: 58, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, paddingVertical: 8 },
  optionAvatar: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  optionInitial: { fontSize: 15, fontWeight: '800' },
  optionCopy: { flex: 1, marginLeft: 10 },
  optionName: { fontSize: 14, fontWeight: '700' },
  optionPhone: { fontSize: 10, marginTop: 3 },
  emptyPicker: { paddingVertical: 25, textAlign: 'center', fontSize: 13 },
  multiline: { minHeight: 92, paddingTop: 13, textAlignVertical: 'top' },
  stat: { flex: 1, minHeight: 94, borderRadius: 16, padding: 12, justifyContent: 'space-between' },
  statLabel: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  statValue: { fontSize: 20, fontWeight: '800', letterSpacing: -0.6 },
  statDetail: { fontSize: 11 },
  empty: { borderWidth: 1, borderRadius: 18, alignItems: 'center', padding: 24, gap: 8 },
  emptyTitle: { fontSize: 15, fontWeight: '700' },
  emptyText: { fontSize: 13, textAlign: 'center', lineHeight: 19 },
});