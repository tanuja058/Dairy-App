import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useState } from 'react';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Button, CustomerPicker, Field, SectionTitle } from '@/components/AppUI';
import { money, todayKey, PaymentMethod, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function PaymentsScreen() {
  const colors = useColors();
  const { data, addPayment } = useMilk();
  const [customerId, setCustomerId] = useState(data.customers[0]?.id ?? '');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('UPI');
  const [note, setNote] = useState('');
  const save = () => {
    if (!customerId || Number(amount) <= 0) { Alert.alert('Add a valid amount', 'Payment amount must be greater than zero.'); return; }
    addPayment({ customerId, date: todayKey(), amount: Number(amount), method, note });
    Alert.alert('Payment saved', `${money(Number(amount))} added as a ${method} payment.`);
    setAmount(''); setNote('');
  };
  return <KeyboardAwareScrollViewCompat style={[styles.root, { backgroundColor: colors.background }]} contentContainerStyle={styles.content}>
    <Text style={[styles.title, { color: colors.foreground }]}>Record payment</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Payment credits are reflected in the customer ledger immediately.</Text>
    <CustomerPicker customers={data.customers} value={customerId} onChange={setCustomerId} />
    <Field label="Amount ₹" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0" />
    <Text style={[styles.label, { color: colors.mutedForeground }]}>Payment method</Text><View style={styles.methods}>{(['Cash', 'UPI', 'Bank transfer', 'Other'] as PaymentMethod[]).map((item) => <Pressable key={item} onPress={() => setMethod(item)} style={[styles.method, { backgroundColor: method === item ? colors.primary : colors.card, borderColor: method === item ? colors.primary : colors.border }]}><Text style={{ color: method === item ? '#FFFFFF' : colors.foreground, fontSize: 12, fontWeight: '700' }}>{item}</Text></Pressable>)}</View>
    <Field label="Notes" value={note} onChangeText={setNote} placeholder="Optional payment note" multiline />
    <Button label="Save payment" icon="check" onPress={save} /><View style={{ marginTop: 9 }}><Button label="Done" tone="secondary" onPress={() => router.back()} /></View>
  </KeyboardAwareScrollViewCompat>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, content: { paddingHorizontal: 16, paddingTop: 18, paddingBottom: 50, width: '100%', maxWidth: 640, alignSelf: 'center' }, title: { fontSize: 25, fontWeight: '800', letterSpacing: -0.9, marginBottom: 5 }, subtitle: { fontSize: 12, lineHeight: 18, marginBottom: 22 }, label: { fontSize: 12, fontWeight: '600', marginBottom: 8 }, methods: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 }, method: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
});