import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, EmptyState, SectionTitle, StatCard, uiStyles } from '@/components/AppUI';
import { buildDuePaymentMessage, sendWhatsAppMessage } from '@/lib/whatsapp';
import { money, quantity, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function RemindersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, customerBalance } = useMilk();
  const dueCustomers = data.customers
    .map((customer) => ({ customer, balance: customerBalance(customer.id) }))
    .filter(({ balance }) => balance > 0)
    .sort((a, b) => b.balance - a.balance);
  const totalDue = dueCustomers.reduce((sum, item) => sum + item.balance, 0);

  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 17 }]}>
      <View style={styles.header}><View><Text style={[styles.eyebrow, { color: colors.primary }]}>PAYMENT FOLLOW-UP</Text><Text style={[styles.title, { color: colors.foreground }]}>Reminders</Text></View><View style={[styles.headerIcon, { backgroundColor: '#E3F1E8' }]}><Feather name="message-circle" size={20} color={colors.primary} /></View></View>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Send a polite, personalized WhatsApp reminder to customers with a due balance.</Text>
      <View style={styles.stats}><StatCard label="Total due" value={money(totalDue)} detail={`${dueCustomers.length} customers`} tone="red" /><StatCard label="Delivery" value="WhatsApp" detail="review before send" tone="green" /></View>
      <View style={[styles.notice, { backgroundColor: '#F8EED8' }]}><Feather name="info" size={17} color="#8B671E" /><Text style={[styles.noticeText, { color: '#765818' }]}>Each message opens in WhatsApp with the due amount already filled in. You can edit it before sending.</Text></View>
      <SectionTitle title="Customers with due payments" />
      {dueCustomers.length === 0 ? <EmptyState icon="check-circle" title="No due payments" text="All customer accounts are currently settled." /> : dueCustomers.map(({ customer, balance }) => {
        const entries = data.entries.filter((entry) => entry.customerId === customer.id);
        const milkLitres = entries.reduce((sum, entry) => sum + quantity(entry), 0);
        return <View key={customer.id} style={[styles.customerCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Pressable onPress={() => router.push(`/customer/${customer.id}`)} style={styles.customerTop}><View style={styles.avatar}><Text style={[styles.avatarText, { color: colors.primary }]}>{customer.name.slice(0, 1)}</Text></View><View style={styles.customerCopy}><Text style={[styles.customerName, { color: colors.foreground }]}>{customer.name}</Text><Text style={[styles.customerMeta, { color: colors.mutedForeground }]}>{customer.phone} · {milkLitres.toFixed(2)} L collected</Text></View><View style={styles.dueCopy}><Text style={[styles.dueAmount, { color: colors.destructive }]}>{money(balance)}</Text><Text style={[styles.dueLabel, { color: colors.mutedForeground }]}>due</Text></View></Pressable>
          <View style={styles.cardActions}><Button label="Send WhatsApp reminder" icon="message-circle" small onPress={() => sendWhatsAppMessage(customer.phone, buildDuePaymentMessage(customer, data))} /><Pressable onPress={() => router.push(`/customer/${customer.id}`)} style={styles.viewButton}><Text style={[styles.viewText, { color: colors.primary }]}>View ledger</Text><Feather name="chevron-right" size={15} color={colors.primary} /></Pressable></View>
        </View>;
      })}
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' }, eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.3 }, title: { fontSize: 28, fontWeight: '800', letterSpacing: -1, marginTop: 5 }, headerIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, subtitle: { fontSize: 13, lineHeight: 19, marginTop: 7, marginBottom: 22 }, stats: { flexDirection: 'row', gap: 10, marginBottom: 12 }, notice: { borderRadius: 15, padding: 13, flexDirection: 'row', gap: 9, marginBottom: 23 }, noticeText: { flex: 1, fontSize: 11, lineHeight: 17 }, customerCard: { borderWidth: 1, borderRadius: 18, padding: 13, marginBottom: 10 }, customerTop: { flexDirection: 'row', alignItems: 'center' }, avatar: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#E3F1E8', alignItems: 'center', justifyContent: 'center' }, avatarText: { fontSize: 18, fontWeight: '800' }, customerCopy: { flex: 1, marginLeft: 11 }, customerName: { fontSize: 14, fontWeight: '800' }, customerMeta: { fontSize: 10, marginTop: 5 }, dueCopy: { alignItems: 'flex-end' }, dueAmount: { fontSize: 15, fontWeight: '800' }, dueLabel: { fontSize: 10, marginTop: 3 }, cardActions: { flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: '#EEF2EC', marginTop: 13, paddingTop: 12 }, viewButton: { flex: 1, flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 3 }, viewText: { fontSize: 11, fontWeight: '800' },
});