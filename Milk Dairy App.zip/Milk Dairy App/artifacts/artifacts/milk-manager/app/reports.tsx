import { Feather } from '@expo/vector-icons';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, SectionTitle, StatCard, uiStyles } from '@/components/AppUI';
import { formatDate, money, quantity, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function ReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data } = useMilk();
  const totalQuantity = data.entries.reduce((sum, entry) => sum + quantity(entry), 0);
  const totalAmount = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  const totalPayments = data.payments.reduce((sum, payment) => sum + payment.amount, 0);
  const activeCustomers = data.customers.filter((customer) => customer.status === 'Active').length;
  const shiftTotals = (shift: 'Morning' | 'Evening') => data.entries.filter((entry) => entry.shift === shift).reduce((sum, entry) => sum + quantity(entry), 0);
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 17 }]}>
    <View style={styles.header}><View><Text style={[styles.eyebrow, { color: colors.primary }]}>BUSINESS INSIGHTS</Text><Text style={[styles.title, { color: colors.foreground }]}>Reports</Text></View><Feather name="bar-chart-2" size={24} color={colors.primary} /></View>
    <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A live summary built from your saved entries and payments.</Text>
    <View style={styles.grid}><StatCard label="Total milk" value={`${totalQuantity.toFixed(2)} L`} detail={`${data.entries.length} entries`} /><StatCard label="Milk value" value={money(totalAmount)} detail="all collections" tone="cream" /></View>
    <View style={styles.grid}><StatCard label="Payments" value={money(totalPayments)} detail="received" tone="green" /><StatCard label="Customers" value={`${activeCustomers}`} detail="active accounts" tone="orange" /></View>
    <SectionTitle title="Shift collection" />
    <View style={[styles.reportCard, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={styles.reportLine}><View style={[styles.dot, { backgroundColor: colors.primary }]} /><Text style={[styles.reportLabel, { color: colors.foreground }]}>Morning</Text><Text style={[styles.reportValue, { color: colors.foreground }]}>{shiftTotals('Morning').toFixed(2)} L</Text></View><View style={styles.barTrack}><View style={[styles.bar, { backgroundColor: colors.primary, width: `${totalQuantity ? Math.min(100, shiftTotals('Morning') / totalQuantity * 100) : 0}%` }]} /></View><View style={styles.reportLine}><View style={[styles.dot, { backgroundColor: '#C78B31' }]} /><Text style={[styles.reportLabel, { color: colors.foreground }]}>Evening</Text><Text style={[styles.reportValue, { color: colors.foreground }]}>{shiftTotals('Evening').toFixed(2)} L</Text></View><View style={styles.barTrack}><View style={[styles.bar, { backgroundColor: '#C78B31', width: `${totalQuantity ? Math.min(100, shiftTotals('Evening') / totalQuantity * 100) : 0}%` }]} /></View></View>
    <SectionTitle title="Collection by customer" /><View style={[styles.reportCard, { backgroundColor: colors.card, borderColor: colors.border }]}>{data.customers.map((customer) => { const customerEntries = data.entries.filter((entry) => entry.customerId === customer.id); const litres = customerEntries.reduce((sum, entry) => sum + quantity(entry), 0); return <View key={customer.id} style={styles.customerReport}><Text style={[styles.reportLabel, { color: colors.foreground }]}>{customer.name}</Text><Text style={[styles.reportValue, { color: colors.primary }]}>{litres.toFixed(2)} L</Text></View>; })}</View>
    <View style={styles.actions}><Button label="Export / share summary" icon="share-2" tone="secondary" onPress={() => router.push('/settings')} /><Text style={[styles.generated, { color: colors.mutedForeground }]}>Updated {formatDate(new Date().toISOString().slice(0, 10))}</Text></View>
  </ScrollView></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, header: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' }, eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.3 }, title: { fontSize: 28, fontWeight: '800', letterSpacing: -1, marginTop: 5 }, subtitle: { fontSize: 13, lineHeight: 19, marginTop: 6, marginBottom: 24 }, grid: { flexDirection: 'row', gap: 10, marginBottom: 10 }, reportCard: { borderWidth: 1, borderRadius: 18, padding: 16, marginBottom: 23 }, reportLine: { flexDirection: 'row', alignItems: 'center' }, dot: { width: 8, height: 8, borderRadius: 4, marginRight: 8 }, reportLabel: { fontSize: 13, flex: 1 }, reportValue: { fontSize: 13, fontWeight: '800' }, barTrack: { height: 7, backgroundColor: '#EEF2EC', borderRadius: 4, marginVertical: 10 }, bar: { height: 7, borderRadius: 4 }, customerReport: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF2EC' }, actions: { marginTop: -5, gap: 12 }, generated: { fontSize: 11, textAlign: 'center' },
});