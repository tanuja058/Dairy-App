import { Feather } from '@expo/vector-icons';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, SectionTitle, StatCard, uiStyles } from '@/components/AppUI';
import { formatDate, money, quantity, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';
import { buildDuePaymentMessage, sendWhatsAppMessage } from '@/lib/whatsapp';

export default function CustomerProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data, customerBalance } = useMilk();
  const customer = data.customers.find((item) => item.id === id);
  if (!customer) return <View style={[styles.missing, { backgroundColor: colors.background }]}><Text style={{ color: colors.foreground }}>Customer not found.</Text></View>;
  const entries = data.entries.filter((entry) => entry.customerId === customer.id);
  const payments = data.payments.filter((payment) => payment.customerId === customer.id);
  const monthKey = new Date().toISOString().slice(0, 7);
  const monthEntries = entries.filter((entry) => entry.date.startsWith(monthKey));
  const lastPayment = payments.sort((a, b) => b.date.localeCompare(a.date))[0];
  const sendReminder = () => sendWhatsAppMessage(customer.phone, buildDuePaymentMessage(customer, data));
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 16 }]}>
    <View style={styles.hero}><View style={[styles.avatar, { backgroundColor: '#E3F1E8' }]}><Text style={[styles.initial, { color: colors.primary }]}>{customer.name.slice(0, 1)}</Text></View><Text style={[styles.name, { color: colors.foreground }]}>{customer.name}</Text><Text style={[styles.phone, { color: colors.mutedForeground }]}>{customer.phone} · {customer.address || 'No address'}</Text><View style={[styles.status, { backgroundColor: customer.status === 'Active' ? '#E3F1E8' : colors.muted }]}><Text style={{ color: customer.status === 'Active' ? colors.primary : colors.mutedForeground, fontSize: 11, fontWeight: '800' }}>{customer.status}</Text></View></View>
    <View style={styles.grid}><StatCard label="Outstanding" value={money(Math.max(0, customerBalance(customer.id)))} detail="current balance" tone={customerBalance(customer.id) > 0 ? 'red' : 'green'} /><StatCard label="This month" value={`${monthEntries.reduce((sum, entry) => sum + quantity(entry), 0).toFixed(2)} L`} detail={money(monthEntries.reduce((sum, entry) => sum + entry.amount, 0))} tone="cream" /></View>
    <View style={styles.grid}><StatCard label="Payments" value={money(payments.reduce((sum, payment) => sum + payment.amount, 0))} detail={lastPayment ? `Last ${formatDate(lastPayment.date)}` : 'none yet'} tone="orange" /><StatCard label="Rate rows" value={`${customer.rates.length}`} detail="fat chart values" /></View>
    <View style={styles.actionGrid}><Button label="Add milk" icon="plus" onPress={() => router.push('/(tabs)/entries')} /><Button label="Record payment" icon="credit-card" tone="secondary" onPress={() => router.push('/payments')} /><Button label="WhatsApp reminder" icon="message-circle" tone="secondary" onPress={sendReminder} /></View>
    <SectionTitle title="Recent transactions" />
    {[...entries.map((entry) => ({ id: entry.id, date: entry.date, title: `${entry.shift} milk`, detail: `${quantity(entry).toFixed(2)} L · Fat ${entry.fat.toFixed(1)}`, amount: entry.amount, credit: false })), ...payments.map((payment) => ({ id: payment.id, date: payment.date, title: `${payment.method} payment`, detail: payment.note || 'Payment received', amount: payment.amount, credit: true }))].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6).map((item) => <View key={item.id} style={[styles.transaction, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name={item.credit ? 'arrow-down-left' : 'arrow-up-right'} size={16} color={item.credit ? colors.primary : '#B46A16'} /><View style={styles.txCopy}><Text style={[styles.txTitle, { color: colors.foreground }]}>{item.title}</Text><Text style={[styles.txDetail, { color: colors.mutedForeground }]}>{formatDate(item.date)} · {item.detail}</Text></View><Text style={[styles.txAmount, { color: item.credit ? colors.primary : colors.destructive }]}>{item.credit ? '+' : '-'}{money(item.amount)}</Text></View>)}
  </ScrollView></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, missing: { flex: 1, alignItems: 'center', justifyContent: 'center' }, hero: { alignItems: 'center', paddingVertical: 13 }, avatar: { width: 74, height: 74, borderRadius: 26, alignItems: 'center', justifyContent: 'center' }, initial: { fontSize: 34, fontWeight: '800' }, name: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5, marginTop: 12 }, phone: { fontSize: 12, marginTop: 5 }, status: { paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8, marginTop: 10 }, grid: { flexDirection: 'row', gap: 10, marginBottom: 10 }, actionGrid: { gap: 9, marginVertical: 18 }, transaction: { borderWidth: 1, borderRadius: 16, padding: 13, flexDirection: 'row', alignItems: 'center', marginBottom: 8 }, txCopy: { flex: 1, marginLeft: 10 }, txTitle: { fontSize: 13, fontWeight: '700' }, txDetail: { fontSize: 10, marginTop: 4 }, txAmount: { fontSize: 12, fontWeight: '800' },
});