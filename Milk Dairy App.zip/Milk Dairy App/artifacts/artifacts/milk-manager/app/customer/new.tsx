import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useState } from 'react';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Button, Field, SectionTitle } from '@/components/AppUI';
import { useMilk, RateRow } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function NewCustomerScreen() {
  const colors = useColors();
  const { addCustomer } = useMilk();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [fromFat, setFromFat] = useState('3');
  const [toFat, setToFat] = useState('6');
  const [step, setStep] = useState('0.5');
  const [startingRate, setStartingRate] = useState('40');
  const [increase, setIncrease] = useState('2.5');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
  const [rates, setRates] = useState<RateRow[]>([]);

  const generate = () => {
    const start = Number(fromFat); const end = Number(toFat); const increment = Number(step);
    if (!increment || end < start) { Alert.alert('Check the range', 'Enter a valid fat range and step.'); return; }
    const rows: RateRow[] = [];
    for (let fat = start; fat <= end + 0.001 && rows.length < 100; fat += increment) rows.push({ fat: Math.round(fat * 10) / 10, rate: Math.round((Number(startingRate) + rows.length * Number(increase)) * 100) / 100 });
    setRates(rows);
  };
  const save = () => {
    if (!name.trim() || !/^\d{10}$/.test(phone.replace(/\D/g, ''))) { Alert.alert('Required details missing', 'Add a customer name and a valid 10-digit phone number.'); return; }
    addCustomer({ name: name.trim(), phone: phone.replace(/\D/g, ''), address: address.trim(), status, rates });
    router.back();
  };
  return <KeyboardAwareScrollViewCompat style={[styles.root, { backgroundColor: colors.background }]} contentContainerStyle={styles.content}>
    <Text style={[styles.title, { color: colors.foreground }]}>New customer</Text>
    <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Create an account and set the fat-based rate chart.</Text>
    <Field label="Customer name *" value={name} onChangeText={setName} placeholder="e.g. Ananda Pandit" />
    <Field label="Phone number *" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="10-digit mobile number" />
    <Field label="Address" value={address} onChangeText={setAddress} placeholder="Collection address" />
    <Text style={[styles.label, { color: colors.mutedForeground }]}>Status</Text>
    <View style={styles.statusRow}>{(['Active', 'Inactive'] as const).map((item) => <Pressable key={item} onPress={() => setStatus(item)} style={[styles.statusButton, { backgroundColor: status === item ? colors.primary : colors.card, borderColor: status === item ? colors.primary : colors.border }]}><Text style={{ color: status === item ? '#FFFFFF' : colors.foreground, fontWeight: '700', fontSize: 13 }}>{item}</Text></Pressable>)}</View>
    <SectionTitle title="Rate chart" />
    <Text style={[styles.helper, { color: colors.mutedForeground }]}>Generate rates from fat percentage, then review the rows before saving.</Text>
    <View style={styles.grid}><View style={{ flex: 1 }}><Field label="From fat %" value={fromFat} onChangeText={setFromFat} keyboardType="decimal-pad" /></View><View style={{ flex: 1 }}><Field label="To fat %" value={toFat} onChangeText={setToFat} keyboardType="decimal-pad" /></View></View>
    <View style={styles.grid}><View style={{ flex: 1 }}><Field label="Step" value={step} onChangeText={setStep} keyboardType="decimal-pad" /></View><View style={{ flex: 1 }}><Field label="Starting rate ₹" value={startingRate} onChangeText={setStartingRate} keyboardType="decimal-pad" /></View></View>
    <Field label="Rate increase per step ₹" value={increase} onChangeText={setIncrease} keyboardType="decimal-pad" />
    <Button label="Generate rate chart" icon="zap" tone="secondary" onPress={generate} />
    {rates.length > 0 && <View style={[styles.rateBox, { backgroundColor: colors.card, borderColor: colors.border }]}>{rates.map((row) => <View key={row.fat} style={styles.rateRow}><Text style={[styles.rateText, { color: colors.foreground }]}>Fat {row.fat.toFixed(1)}%</Text><Text style={[styles.rateValue, { color: colors.primary }]}>₹{row.rate.toFixed(2)} / L</Text></View>)}</View>}
    <View style={styles.actions}><Button label="Save customer" icon="check" onPress={save} /><Button label="Cancel" tone="secondary" onPress={() => router.back()} /></View>
  </KeyboardAwareScrollViewCompat>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, content: { padding: 20, paddingBottom: 50 }, title: { fontSize: 28, fontWeight: '800', letterSpacing: -1, marginBottom: 5 }, subtitle: { fontSize: 13, lineHeight: 19, marginBottom: 25 }, label: { fontSize: 12, fontWeight: '600', marginBottom: 8 }, statusRow: { flexDirection: 'row', gap: 9, marginBottom: 24 }, statusButton: { flex: 1, borderWidth: 1, minHeight: 46, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, helper: { fontSize: 12, lineHeight: 18, marginTop: -5, marginBottom: 17 }, grid: { flexDirection: 'row', gap: 10 }, rateBox: { borderWidth: 1, borderRadius: 16, padding: 13, marginTop: 14, marginBottom: 20 }, rateRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#EEF2EC' }, rateText: { fontSize: 12 }, rateValue: { fontWeight: '700', fontSize: 12 }, actions: { gap: 9, marginTop: 12 },
});