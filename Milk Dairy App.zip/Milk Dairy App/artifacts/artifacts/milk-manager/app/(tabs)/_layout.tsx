import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';

export default function TabLayout() {
  const colors = useColors();
  const isWeb = Platform.OS === 'web';
  return <Tabs screenOptions={{
    headerShown: false,
    tabBarActiveTintColor: colors.primary,
    tabBarInactiveTintColor: colors.mutedForeground,
    tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border, borderTopWidth: 1, height: isWeb ? 84 : 66, paddingTop: 7 },
    tabBarLabelStyle: { fontSize: 10, fontWeight: '600', marginBottom: isWeb ? 12 : 4 },
  }}>
    <Tabs.Screen name="index" options={{ title: 'Overview', tabBarIcon: ({ color }) => <Feather name="grid" size={21} color={color} /> }} />
    <Tabs.Screen name="entries" options={{ title: 'Daily entry', tabBarIcon: ({ color }) => <Feather name="edit-3" size={21} color={color} /> }} />
    <Tabs.Screen name="customers" options={{ title: 'Customers', tabBarIcon: ({ color }) => <Feather name="users" size={21} color={color} /> }} />
    <Tabs.Screen name="ledger" options={{ title: 'Ledger', tabBarIcon: ({ color }) => <Feather name="book-open" size={21} color={color} /> }} />
    <Tabs.Screen name="more" options={{ title: 'More', tabBarIcon: ({ color }) => <Feather name="more-horizontal" size={22} color={color} /> }} />
  </Tabs>;
}
