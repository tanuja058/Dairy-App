import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useState } from 'react';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Brand } from '@/components/Brand';
import { Button, CustomerPicker, EmptyState, Field, SectionTitle, uiStyles } from '@/components/AppUI';
import { formatDate, money, quantity, todayKey, useMilk, Shift } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function EntriesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, addEntry, updateEntry, deleteEntry, getRate } = useMilk();
  const [shift, setShift] = useState<Shift>('Morning');
  const [customerId, setCustomerId] = useState(data.customers[0]?.id ?? '');
  const [date, setDate] = useState(todayKey());
  const [liters, setLiters] = useState('');
  const [ml, setMl] = useState('');
  const [fat, setFat] = useState('4.5');
  const [remarks, setRemarks] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const rate = getRate(customerId, Number(fat));
  const previewAmount = (Number(liters || 0) + Number(ml || 0) / 1000) * rate;
  const dayEntries = data.entries.filter((entry) => entry.date === date);

  const clearForm = () => {
    setEditingId(null);
    setLiters('');
    setMl('');
    setFat('4.5');
    setRemarks('');
  };

  const save = () => {
    if (!customerId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || Number(liters || 0) <= 0 || Number(ml || 0) > 999 || Number(fat || 0) <= 0) {
      Alert.alert('Check the entry', 'Enter a date as YYYY-MM-DD, customer, liters, valid ML (0–999), and fat percentage.');
      return;
    }
    const input = { customerId, date, shift, liters: Number(liters), ml: Number(ml || 0), fat: Number(fat), remarks };
    const saved = editingId ? updateEntry(editingId, input) : addEntry(input);
    if (!saved) Alert.alert('Duplicate entry', 'An entry already exists for this customer and shift.');
    else { clearForm(); Alert.alert(editingId ? 'Entry updated' : 'Entry saved', `${money(previewAmount)} is reflected in the ledger.`); }
  };

  const editEntry = (entry: typeof data.entries[number]) => {
    setEditingId(entry.id);
    setCustomerId(entry.customerId);
    setDate(entry.date);
    setShift(entry.shift);
    setLiters(String(entry.liters));
    setMl(String(entry.ml));
    setFat(String(entry.fat));
    setRemarks(entry.remarks);
  };

  const confirmDelete = (id: string) => Alert.alert('Delete this entry?', 'This will remove the milk collection from the customer ledger.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => deleteEntry(id) }]);

  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <KeyboardAwareScrollViewCompat contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 18 }]}>
      <View style={styles.top}><Brand compact /><View style={[styles.datePill, { backgroundColor: colors.secondary }]}><Feather name="calendar" size={14} color={colors.primary} /><Text style={[styles.dateText, { color: colors.primary }]}>{formatDate(date)}</Text></View></View>
      <Text style={[styles.title, { color: colors.foreground }]}>Daily collection</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Record milk in a few taps. Rate and amount update automatically.</Text>
      <View style={[styles.shiftSwitch, { backgroundColor: colors.muted }]}>{(['Morning', 'Evening'] as Shift[]).map((item) => <Pressable key={item} onPress={() => setShift(item)} style={[styles.shift, shift === item && { backgroundColor: colors.primary }]}><Text style={[styles.shiftText, { color: shift === item ? '#FFFFFF' : colors.mutedForeground }]}>{item}</Text></Pressable>)}</View>
      <SectionTitle title={editingId ? 'Edit collection' : 'Collection details'} />
      <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-09-30" />
      <CustomerPicker customers={data.customers} value={customerId} onChange={setCustomerId} />
      <View style={styles.twoCol}><View style={{ flex: 1 }}><Field label="Liters" value={liters} onChangeText={setLiters} keyboardType="decimal-pad" placeholder="0" /></View><View style={{ flex: 1 }}><Field label="ML" value={ml} onChangeText={setMl} keyboardType="number-pad" placeholder="0–999" /></View></View>
      <Field label="Fat %" value={fat} onChangeText={setFat} keyboardType="decimal-pad" placeholder="4.5" />
      <View style={[styles.calcCard, { backgroundColor: colors.card, borderColor: colors.border }]}><View><Text style={[styles.calcLabel, { color: colors.mutedForeground }]}>RATE / L</Text><Text style={[styles.calcValue, { color: colors.foreground }]}>{rate ? `₹${rate.toFixed(2)}` : '—'}</Text></View><View style={styles.calcDivider} /><View><Text style={[styles.calcLabel, { color: colors.mutedForeground }]}>AMOUNT</Text><Text style={[styles.calcValue, { color: colors.primary }]}>{previewAmount ? money(previewAmount) : '—'}</Text></View></View>
      <Field label="Remarks (optional)" value={remarks} onChangeText={setRemarks} placeholder="Any note for this collection" />
      <Button label={editingId ? 'Update entry' : 'Save entry'} icon={editingId ? 'save' : 'check'} onPress={save} />
      {editingId && <View style={{ marginTop: 8 }}><Button label="Cancel editing" tone="secondary" onPress={clearForm} /></View>}
      <SectionTitle title={`${formatDate(date)} register`} action={`${dayEntries.length} entries`} />
      {dayEntries.length === 0 ? <EmptyState icon="clipboard" title="No entries for this date" text="Change the date above or add a collection entry." /> : dayEntries.map((entry) => { const customer = data.customers.find((item) => item.id === entry.customerId); return <View key={entry.id} style={[styles.entryRow, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={styles.entryIcon}><Feather name={entry.shift === 'Morning' ? 'sunrise' : 'sunset'} size={16} color={colors.primary} /></View><View style={styles.entryInfo}><Text style={[styles.entryName, { color: colors.foreground }]}>{customer?.name}</Text><Text style={[styles.entryDetail, { color: colors.mutedForeground }]}>{entry.shift} · {quantity(entry).toFixed(2)} L · Fat {entry.fat.toFixed(1)}</Text></View><View style={styles.entryAmount}><Text style={[styles.amount, { color: colors.foreground }]}>{money(entry.amount)}</Text><View style={styles.entryActions}><Pressable onPress={() => editEntry(entry)}><Text style={[styles.edit, { color: colors.primary }]}>Edit</Text></Pressable><Pressable onPress={() => confirmDelete(entry.id)}><Text style={[styles.delete, { color: colors.destructive }]}>Delete</Text></Pressable></View></View></View>; })}
    </KeyboardAwareScrollViewCompat>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 26 },
  datePill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8 },
  dateText: { fontSize: 11, fontWeight: '700' },
  title: { fontSize: 27, fontWeight: '800', letterSpacing: -1, marginBottom: 5 },
  subtitle: { fontSize: 13, lineHeight: 19, marginBottom: 20 },
  shiftSwitch: { flexDirection: 'row', borderRadius: 14, padding: 4, marginBottom: 25 },
  shift: { flex: 1, borderRadius: 11, minHeight: 40, alignItems: 'center', justifyContent: 'center' },
  shiftText: { fontSize: 13, fontWeight: '700' },
  fieldLabel: { fontSize: 12, fontWeight: '600', marginBottom: 8 },
  twoCol: { flexDirection: 'row', gap: 10 },
  calcCard: { borderWidth: 1, borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  calcLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 0.8 },
  calcValue: { fontSize: 21, fontWeight: '800', marginTop: 6 },
  calcDivider: { width: 1, height: 36, backgroundColor: '#DDE6DC', marginHorizontal: 22 },
  entryRow: { borderWidth: 1, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  entryIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#E4F0E7', alignItems: 'center', justifyContent: 'center' },
  entryInfo: { flex: 1, marginLeft: 10 },
  entryName: { fontWeight: '700', fontSize: 13 },
  entryDetail: { fontSize: 11, marginTop: 4 },
  entryAmount: { alignItems: 'flex-end' },
  amount: { fontSize: 13, fontWeight: '800' },
  entryActions: { flexDirection: 'row', gap: 9, marginTop: 5 },
  edit: { fontSize: 10, fontWeight: '800' },
  delete: { fontSize: 10, fontWeight: '700', marginTop: 5 },
});