import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { ScrollView, StyleSheet, Text, View, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Brand } from '@/components/Brand';
import { Button, SectionTitle, StatCard, uiStyles } from '@/components/AppUI';
import { formatDate, money, quantity, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';
import { buildDuePaymentMessage, sendWhatsAppMessage } from '@/lib/whatsapp';

export default function Dashboard() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, customerBalance } = useMilk();
  const today = new Date().toISOString().slice(0, 10);
  const todayEntries = data.entries.filter((entry) => entry.date === today);
  const liters = todayEntries.reduce((sum, entry) => sum + quantity(entry), 0);
  const amount = todayEntries.reduce((sum, entry) => sum + entry.amount, 0);
  const morning = todayEntries.filter((entry) => entry.shift === 'Morning').reduce((sum, entry) => sum + quantity(entry), 0);
  const evening = todayEntries.filter((entry) => entry.shift === 'Evening').reduce((sum, entry) => sum + quantity(entry), 0);
  const outstanding = data.customers.map((customer) => ({ customer, balance: customerBalance(customer.id) })).filter((item) => item.balance > 0).sort((a, b) => b.balance - a.balance);
  const received = data.payments.reduce((sum, payment) => sum + payment.amount, 0);

  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 16 }]}>
      <View style={styles.header}><Brand /><Pressable onPress={() => router.push('/settings')} style={[styles.avatar, { backgroundColor: colors.secondary }]}><Feather name="settings" size={18} color={colors.primary} /></Pressable></View>
      <Text style={[styles.eyebrow, { color: colors.primary }]}>GOOD MORNING</Text>
      <Text style={[styles.greeting, { color: colors.foreground }]}>Your dairy at a glance</Text>
      <Text style={[styles.date, { color: colors.mutedForeground }]}>{formatDate(today)}</Text>

      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <View><Text style={styles.heroKicker}>TODAY'S COLLECTION</Text><Text style={styles.heroValue}>{liters.toFixed(2)} L</Text><Text style={styles.heroDetail}>{money(amount)} milk value</Text></View>
        <View style={styles.heroOrb}><Feather name="droplet" size={28} color="#F7E8C8" /></View>
      </View>

      <View style={styles.statGrid}><StatCard label="Morning" value={`${morning.toFixed(2)} L`} detail="collection" /><StatCard label="Evening" value={`${evening.toFixed(2)} L`} detail="collection" tone="cream" /></View>
      <View style={styles.statGrid}><StatCard label="Customers" value={`${data.customers.filter((c) => c.status === 'Active').length}`} detail={`${data.customers.length} total`} tone="orange" /><StatCard label="Received" value={money(received)} detail="all payments" /></View>

      <SectionTitle title="Quick actions" />
      <View style={styles.quickGrid}>
        <Button label="Daily entry" icon="plus-circle" onPress={() => router.push('/(tabs)/entries')} />
        <Button label="Add customer" icon="user-plus" tone="secondary" onPress={() => router.push('/customer/new')} />
        <Button label="Record payment" icon="credit-card" tone="secondary" onPress={() => router.push('/payments')} />
      </View>

      <SectionTitle title="Outstanding balances" action="Ledger" onAction={() => router.push('/(tabs)/ledger')} />
      {outstanding.length === 0 ? <Text style={[styles.noOutstanding, { color: colors.mutedForeground }]}>All customer accounts are settled.</Text> : outstanding.slice(0, 4).map(({ customer, balance }) => <View key={customer.id} style={[styles.balanceRow, { backgroundColor: colors.card, borderColor: colors.border }]}><Pressable onPress={() => router.push(`/customer/${customer.id}`)} style={styles.balanceTap}><View style={styles.customerBadge}><Text style={[styles.customerInitial, { color: colors.primary }]}>{customer.name.slice(0, 1)}</Text></View><View style={styles.balanceMeta}><Text style={[styles.balanceName, { color: colors.foreground }]}>{customer.name}</Text><Text style={[styles.balancePhone, { color: colors.mutedForeground }]}>{customer.phone}</Text></View><View style={styles.balanceRight}><Text style={[styles.balanceAmount, { color: colors.destructive }]}>{money(balance)}</Text><Text style={[styles.balanceHint, { color: colors.mutedForeground }]}>outstanding</Text></View></Pressable><Pressable onPress={() => sendWhatsAppMessage(customer.phone, buildDuePaymentMessage(customer, data))} style={[styles.whatsappButton, { backgroundColor: '#E3F1E8' }]}><Feather name="message-circle" size={14} color={colors.primary} /><Text style={[styles.whatsappText, { color: colors.primary }]}>WhatsApp</Text></Pressable></View>)}
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 },
  avatar: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { fontSize: 11, fontWeight: '800', letterSpacing: 1.4 },
  greeting: { fontSize: 23, fontWeight: '800', letterSpacing: -0.8, marginTop: 4 },
  date: { fontSize: 13, marginTop: 5, marginBottom: 18 },
  hero: { minHeight: 134, borderRadius: 21, padding: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  heroKicker: { color: '#BFE0C9', fontSize: 11, fontWeight: '800', letterSpacing: 1 },
  heroValue: { color: '#FFFFFF', fontSize: 32, fontWeight: '800', letterSpacing: -1.2, marginTop: 8 },
  heroDetail: { color: '#D3E7D9', fontSize: 13, marginTop: 4 },
  heroOrb: { width: 62, height: 62, borderRadius: 31, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center' },
  statGrid: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  quickGrid: { gap: 10, marginBottom: 26 },
  balanceRow: { borderWidth: 1, borderRadius: 17, padding: 13, flexDirection: 'row', alignItems: 'center', marginBottom: 9 },
  balanceTap: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  customerBadge: { width: 40, height: 40, borderRadius: 14, backgroundColor: '#E4F0E7', alignItems: 'center', justifyContent: 'center' },
  customerInitial: { fontSize: 17, fontWeight: '800' },
  balanceMeta: { flex: 1, marginLeft: 11 },
  balanceName: { fontSize: 14, fontWeight: '700' },
  balancePhone: { fontSize: 11, marginTop: 3 },
  balanceRight: { alignItems: 'flex-end' },
  balanceAmount: { fontSize: 15, fontWeight: '800' },
  balanceHint: { fontSize: 10, marginTop: 3 },
  whatsappButton: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 9, paddingHorizontal: 8, paddingVertical: 7, marginLeft: 5 },
  whatsappText: { fontSize: 10, fontWeight: '800' },
  noOutstanding: { fontSize: 13, paddingVertical: 10 },
});