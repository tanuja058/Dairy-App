import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Brand } from '@/components/Brand';
import { Button, EmptyState, SectionTitle, uiStyles } from '@/components/AppUI';
import { money, useMilk, CustomerStatus } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function CustomersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, customerBalance } = useMilk();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<CustomerStatus | 'All'>('All');
  const filtered = useMemo(() => data.customers.filter((customer) => (filter === 'All' || customer.status === filter) && `${customer.name} ${customer.phone}`.toLowerCase().includes(query.toLowerCase())), [data.customers, filter, query]);
  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 18 }]}>
      <View style={styles.header}><Brand compact /><Pressable onPress={() => router.push('/customer/new')} style={[styles.addButton, { backgroundColor: colors.primary }]}><Feather name="plus" size={18} color="#FFFFFF" /><Text style={styles.addText}>Add</Text></Pressable></View>
      <Text style={[styles.title, { color: colors.foreground }]}>Customers</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{data.customers.length} customer accounts in your dairy</Text>
      <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="search" size={17} color={colors.mutedForeground} /><TextInput value={query} onChangeText={setQuery} placeholder="Search by name or phone" placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.foreground }]} /></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>{(['All', 'Active', 'Inactive'] as const).map((item) => <Pressable key={item} onPress={() => setFilter(item)} style={[styles.filter, { backgroundColor: filter === item ? colors.primary : colors.card, borderColor: filter === item ? colors.primary : colors.border }]}><Text style={[styles.filterText, { color: filter === item ? '#FFFFFF' : colors.mutedForeground }]}>{item}</Text></Pressable>)}</ScrollView>
      <SectionTitle title={`${filtered.length} results`} />
      {filtered.length === 0 ? <EmptyState icon="users" title="No matching customers" text="Try a different name, phone number, or status filter." /> : filtered.map((customer) => <Pressable key={customer.id} onPress={() => router.push(`/customer/${customer.id}`)} style={[styles.customerCard, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={[styles.avatar, { backgroundColor: customer.status === 'Active' ? '#E3F1E8' : colors.muted }]}><Text style={[styles.avatarText, { color: customer.status === 'Active' ? colors.primary : colors.mutedForeground }]}>{customer.name.slice(0, 1)}</Text></View><View style={styles.customerMain}><View style={styles.nameLine}><Text style={[styles.name, { color: colors.foreground }]}>{customer.name}</Text><View style={[styles.status, { backgroundColor: customer.status === 'Active' ? '#E3F1E8' : colors.muted }]}><Text style={[styles.statusText, { color: customer.status === 'Active' ? colors.primary : colors.mutedForeground }]}>{customer.status}</Text></View></View><Text style={[styles.phone, { color: colors.mutedForeground }]}>{customer.phone} · {customer.address || 'No address'}</Text></View><View style={styles.cardRight}><Text style={[styles.balance, { color: customerBalance(customer.id) > 0 ? colors.destructive : colors.primary }]}>{money(Math.max(0, customerBalance(customer.id)))}</Text><Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>balance</Text><Feather name="chevron-right" size={17} color={colors.mutedForeground} /></View></Pressable>)}
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 27 }, addButton: { paddingHorizontal: 13, height: 38, borderRadius: 12, flexDirection: 'row', gap: 5, alignItems: 'center' }, addText: { color: '#FFFFFF', fontSize: 12, fontWeight: '800' }, title: { fontSize: 27, fontWeight: '800', letterSpacing: -1 }, subtitle: { fontSize: 13, marginTop: 5, marginBottom: 18 }, search: { height: 49, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 9 }, searchInput: { flex: 1, fontSize: 14 }, filters: { gap: 8, paddingVertical: 15 }, filter: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 15, paddingVertical: 9 }, filterText: { fontSize: 12, fontWeight: '700' }, customerCard: { borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 9, flexDirection: 'row', alignItems: 'center' }, avatar: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, avatarText: { fontWeight: '800', fontSize: 18 }, customerMain: { flex: 1, marginLeft: 11 }, nameLine: { flexDirection: 'row', alignItems: 'center', gap: 7 }, name: { fontSize: 14, fontWeight: '700', flexShrink: 1 }, status: { paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 }, statusText: { fontSize: 9, fontWeight: '800' }, phone: { fontSize: 11, marginTop: 6 }, cardRight: { alignItems: 'flex-end', gap: 3 }, balance: { fontSize: 13, fontWeight: '800' }, balanceLabel: { fontSize: 9 }, 
});