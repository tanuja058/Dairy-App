import { Feather } from '@expo/vector-icons';
import { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Brand } from '@/components/Brand';
import { CustomerPicker, EmptyState, SectionTitle, StatCard, uiStyles } from '@/components/AppUI';
import { formatDate, money, quantity, useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function LedgerScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, customerBalance } = useMilk();
  const [customerId, setCustomerId] = useState(data.customers[0]?.id ?? '');
  const customer = data.customers.find((item) => item.id === customerId);
  const entries = data.entries.filter((entry) => entry.customerId === customerId);
  const payments = data.payments.filter((payment) => payment.customerId === customerId);
  const totalMilk = entries.reduce((sum, entry) => sum + quantity(entry), 0);
  const totalDebit = entries.reduce((sum, entry) => sum + entry.amount, 0);
  const totalCredit = payments.reduce((sum, payment) => sum + payment.amount, 0);
  const transactions = [...entries.map((entry) => ({ id: entry.id, date: entry.date, title: `${entry.shift} milk collection`, detail: `${quantity(entry).toFixed(2)} L · Fat ${entry.fat.toFixed(1)}`, amount: entry.amount, kind: 'debit' as const })), ...payments.map((payment) => ({ id: payment.id, date: payment.date, title: `${payment.method} payment`, detail: payment.note || 'Payment received', amount: payment.amount, kind: 'credit' as const }))].sort((a, b) => b.date.localeCompare(a.date));
  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 18 }]}>
      <View style={styles.header}><Brand compact /><Feather name="book-open" size={21} color={colors.primary} /></View>
      <Text style={[styles.title, { color: colors.foreground }]}>Customer ledger</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A running account of milk purchases and payments</Text>
      <CustomerPicker customers={data.customers} value={customerId} onChange={setCustomerId} />
      {customer && <><View style={[styles.profile, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={[styles.largeAvatar, { backgroundColor: '#E3F1E8' }]}><Text style={[styles.largeInitial, { color: colors.primary }]}>{customer.name.slice(0, 1)}</Text></View><View><Text style={[styles.profileName, { color: colors.foreground }]}>{customer.name}</Text><Text style={[styles.profilePhone, { color: colors.mutedForeground }]}>{customer.phone}</Text></View></View><View style={styles.statGrid}><StatCard label="Outstanding" value={money(Math.max(0, customerBalance(customer.id)))} detail="current balance" tone={customerBalance(customer.id) > 0 ? 'red' : 'green'} /><StatCard label="This account" value={`${totalMilk.toFixed(2)} L`} detail={money(totalDebit)} tone="cream" /></View><SectionTitle title="Transactions" action={`${transactions.length} records`} />{transactions.length === 0 ? <EmptyState icon="book-open" title="No transactions" text="Milk entries and payments will appear in this ledger." /> : transactions.map((transaction) => <View key={transaction.id} style={[styles.transaction, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={[styles.transactionIcon, { backgroundColor: transaction.kind === 'credit' ? '#E3F1E8' : '#FFF0DB' }]}><Feather name={transaction.kind === 'credit' ? 'arrow-down-left' : 'arrow-up-right'} size={16} color={transaction.kind === 'credit' ? colors.primary : '#B46A16'} /></View><View style={styles.transactionMain}><Text style={[styles.transactionTitle, { color: colors.foreground }]}>{transaction.title}</Text><Text style={[styles.transactionDetail, { color: colors.mutedForeground }]}>{formatDate(transaction.date)} · {transaction.detail}</Text></View><View style={styles.transactionRight}><Text style={[styles.transactionAmount, { color: transaction.kind === 'credit' ? colors.primary : colors.destructive }]}>{transaction.kind === 'credit' ? '+' : '-'}{money(transaction.amount)}</Text><Text style={[styles.running, { color: colors.mutedForeground }]}>ledger</Text></View></View>)}<View style={[styles.summary, { backgroundColor: colors.primary }]}><Text style={styles.summaryLabel}>NET OUTSTANDING</Text><Text style={styles.summaryValue}>{money(Math.max(0, totalDebit - totalCredit))}</Text><Text style={styles.summaryDetail}>{money(totalCredit)} paid against {money(totalDebit)} milk value</Text></View></>}
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 27 }, title: { fontSize: 27, fontWeight: '800', letterSpacing: -1 }, subtitle: { fontSize: 13, lineHeight: 19, marginTop: 5 }, profile: { borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 10 }, largeAvatar: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }, largeInitial: { fontSize: 20, fontWeight: '800' }, profileName: { fontSize: 15, fontWeight: '800' }, profilePhone: { fontSize: 12, marginTop: 3 }, statGrid: { flexDirection: 'row', gap: 10, marginBottom: 22 }, transaction: { borderWidth: 1, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', marginBottom: 8 }, transactionIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' }, transactionMain: { flex: 1, marginLeft: 10 }, transactionTitle: { fontSize: 13, fontWeight: '700' }, transactionDetail: { fontSize: 10, marginTop: 4 }, transactionRight: { alignItems: 'flex-end' }, transactionAmount: { fontSize: 12, fontWeight: '800' }, running: { fontSize: 9, marginTop: 4 }, summary: { borderRadius: 19, padding: 18, marginTop: 17 }, summaryLabel: { color: '#BFE0C9', fontSize: 10, fontWeight: '800', letterSpacing: 1 }, summaryValue: { color: '#FFFFFF', fontSize: 27, fontWeight: '800', marginTop: 5 }, summaryDetail: { color: '#D3E7D9', fontSize: 11, marginTop: 4 },
});