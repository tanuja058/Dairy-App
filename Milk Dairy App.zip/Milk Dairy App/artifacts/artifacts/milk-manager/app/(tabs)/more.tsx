import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Brand } from '@/components/Brand';
import { uiStyles } from '@/components/AppUI';
import { useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

const items: { label: string; detail: string; icon: keyof typeof Feather.glyphMap; path: '/payments' | '/reminders' | '/settings' }[] = [
  { label: 'Payments', detail: 'Record cash, UPI and bank payments', icon: 'credit-card', path: '/payments' },
  { label: 'Payment reminders', detail: 'Send due balance reminders on WhatsApp', icon: 'message-circle', path: '/reminders' },
  { label: 'Settings', detail: 'Business profile and data backup', icon: 'settings', path: '/settings' },
];

export default function MoreScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data } = useMilk();
  return <View style={[styles.root, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={[uiStyles.scrollContent, { paddingTop: insets.top + 18 }]}>
      <Brand />
      <Text style={[styles.title, { color: colors.foreground }]}>More tools</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Everything you need to keep your dairy running smoothly.</Text>
      {items.map((item) => <Pressable key={item.label} onPress={() => router.push(item.path)} style={({ pressed }) => [styles.item, { backgroundColor: colors.card, borderColor: colors.border }, pressed && { opacity: 0.75 }]}><View style={[styles.icon, { backgroundColor: colors.secondary }]}><Feather name={item.icon} size={20} color={colors.primary} /></View><View style={styles.itemCopy}><Text style={[styles.itemLabel, { color: colors.foreground }]}>{item.label}</Text><Text style={[styles.itemDetail, { color: colors.mutedForeground }]}>{item.detail}</Text></View><Feather name="chevron-right" size={18} color={colors.mutedForeground} /></Pressable>)}
      <View style={[styles.info, { backgroundColor: '#E3F1E8' }]}><Feather name="shield" size={20} color={colors.primary} /><View style={{ flex: 1 }}><Text style={[styles.infoTitle, { color: colors.primary }]}>Offline-first</Text><Text style={[styles.infoText, { color: colors.secondaryForeground }]}>Your data is saved on this device and stays available without internet.</Text></View></View>
      <Text style={[styles.meta, { color: colors.mutedForeground }]}>{data.customers.length} customers · {data.entries.length} milk entries · {data.payments.length} payments</Text>
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, title: { fontSize: 27, fontWeight: '800', letterSpacing: -1, marginTop: 36 }, subtitle: { fontSize: 13, lineHeight: 19, marginTop: 6, marginBottom: 22 }, item: { borderWidth: 1, borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', marginBottom: 10 }, icon: { width: 43, height: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, itemCopy: { flex: 1, marginLeft: 12 }, itemLabel: { fontSize: 15, fontWeight: '800' }, itemDetail: { fontSize: 11, marginTop: 4 }, info: { marginTop: 20, padding: 15, borderRadius: 17, flexDirection: 'row', gap: 11 }, infoTitle: { fontSize: 13, fontWeight: '800' }, infoText: { fontSize: 11, marginTop: 4, lineHeight: 17 }, meta: { textAlign: 'center', fontSize: 11, marginTop: 30 },
});