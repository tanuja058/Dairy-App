import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert, Platform, Share, StyleSheet, Text, View } from 'react-native';
import { useState } from 'react';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Button, Field, SectionTitle } from '@/components/AppUI';
import { useMilk } from '@/lib/milk-store';
import { useColors } from '@/hooks/useColors';

export default function SettingsScreen() {
  const colors = useColors();
  const { data, updateSettings } = useMilk();
  const [businessName, setBusinessName] = useState(data.settings.businessName);
  const [businessPhone, setBusinessPhone] = useState(data.settings.businessPhone);
  const [businessAddress, setBusinessAddress] = useState(data.settings.businessAddress);
  const [upiId, setUpiId] = useState(data.settings.upiId);
  const save = () => { updateSettings({ businessName, businessPhone, businessAddress, upiId }); Alert.alert('Settings saved', 'Your business details are updated.'); };
  const exportData = async () => { await Share.share({ message: JSON.stringify(data, null, 2), title: 'Milk Manager JSON backup' }); };
  const exportPdf = async () => {
    const escapeHtml = (value: string | number) => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const customerRows = data.customers.map((customer) => `<tr><td>${escapeHtml(customer.name)}</td><td>${escapeHtml(customer.phone)}</td><td>${escapeHtml(customer.status)}</td><td>${customer.rates.length} rows</td></tr>`).join('');
    const entryRows = data.entries.map((entry) => {
      const customer = data.customers.find((item) => item.id === entry.customerId);
      return `<tr><td>${escapeHtml(entry.date)}</td><td>${escapeHtml(customer?.name ?? 'Unknown')}</td><td>${escapeHtml(entry.shift)}</td><td>${(entry.liters + entry.ml / 1000).toFixed(2)} L</td><td>${entry.fat.toFixed(1)}%</td><td>₹${entry.amount.toFixed(2)}</td></tr>`;
    }).join('');
    const paymentRows = data.payments.map((payment) => {
      const customer = data.customers.find((item) => item.id === payment.customerId);
      return `<tr><td>${escapeHtml(payment.date)}</td><td>${escapeHtml(customer?.name ?? 'Unknown')}</td><td>${escapeHtml(payment.method)}</td><td>₹${payment.amount.toFixed(2)}</td></tr>`;
    }).join('');
    const totalMilk = data.entries.reduce((sum, entry) => sum + entry.liters + entry.ml / 1000, 0);
    const totalMilkAmount = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalPayments = data.payments.reduce((sum, payment) => sum + payment.amount, 0);
    const html = `<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>
      @page { margin: 28px; } body { font-family: Arial, sans-serif; color: #183229; } h1 { color: #176B4D; margin-bottom: 4px; } h2 { color: #176B4D; border-bottom: 1px solid #DDE6DC; padding-bottom: 6px; margin-top: 24px; } p { color: #607169; } .summary { display: flex; gap: 24px; background: #E3F1E8; padding: 14px; border-radius: 8px; } .summary strong { display: block; font-size: 18px; color: #183229; } table { width: 100%; border-collapse: collapse; font-size: 10px; } th { text-align: left; background: #176B4D; color: #fff; padding: 7px; } td { border-bottom: 1px solid #E8EEE7; padding: 7px; } footer { color: #829088; font-size: 10px; margin-top: 30px; }
    </style></head><body><h1>${escapeHtml(data.settings.businessName)}</h1><p>Milk Manager data backup · Generated ${new Date().toLocaleDateString('en-IN')}</p><p>${escapeHtml(data.settings.businessAddress)} ${data.settings.businessPhone ? `· ${escapeHtml(data.settings.businessPhone)}` : ''}</p><div class="summary"><div><strong>${data.customers.length}</strong>Customers</div><div><strong>${totalMilk.toFixed(2)} L</strong>Milk collected</div><div><strong>₹${totalMilkAmount.toFixed(2)}</strong>Milk value</div><div><strong>₹${totalPayments.toFixed(2)}</strong>Payments</div></div><h2>Customers</h2><table><tr><th>Name</th><th>Phone</th><th>Status</th><th>Rate chart</th></tr>${customerRows || '<tr><td colspan="4">No customers</td></tr>'}</table><h2>Milk entries</h2><table><tr><th>Date</th><th>Customer</th><th>Shift</th><th>Quantity</th><th>Fat</th><th>Amount</th></tr>${entryRows || '<tr><td colspan="6">No milk entries</td></tr>'}</table><h2>Payments</h2><table><tr><th>Date</th><th>Customer</th><th>Method</th><th>Amount</th></tr>${paymentRows || '<tr><td colspan="4">No payments</td></tr>'}</table><footer>Keep this PDF for reference. Use the JSON backup for restoring data into the app.</footer></body></html>`;
    try {
      const { uri } = await Print.printToFileAsync({ html });
      if (Platform.OS !== 'web' && await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: 'Share Milk Manager PDF backup' });
      } else {
        await Share.share({ message: `Milk Manager PDF backup created at ${uri}`, title: 'Milk Manager PDF backup' });
      }
    } catch {
      Alert.alert('PDF export failed', 'Please try again after checking available device storage.');
    }
  };
  const clearData = () => Alert.alert('Clear local data?', 'This removes all customers, entries, payments, and settings from this device.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Clear', style: 'destructive', onPress: () => AsyncStorage.removeItem('milk-manager-data-v1').then(() => Alert.alert('Data cleared', 'Restart the app to begin with a fresh account.')) }]);
  return <KeyboardAwareScrollViewCompat style={[styles.root, { backgroundColor: colors.background }]} contentContainerStyle={styles.content}>
    <Text style={[styles.title, { color: colors.foreground }]}>Settings</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Business details appear on shared summaries and bills.</Text>
    <SectionTitle title="Business profile" /><Field label="Business name" value={businessName} onChangeText={setBusinessName} placeholder="Your dairy name" /><Field label="Business phone" value={businessPhone} onChangeText={setBusinessPhone} keyboardType="phone-pad" placeholder="Contact number" /><Field label="Business address" value={businessAddress} onChangeText={setBusinessAddress} placeholder="Address" multiline /><Field label="UPI ID" value={upiId} onChangeText={setUpiId} placeholder="yourname@upi" /><Button label="Save settings" icon="check" onPress={save} />
    <SectionTitle title="Backup & restore" /><Text style={[styles.helper, { color: colors.mutedForeground }]}>Export a readable PDF for your records, or keep a JSON backup for restoring the app data later.</Text><Button label="Export PDF backup" icon="file-text" tone="secondary" onPress={exportPdf} /><View style={{ height: 8 }} /><Button label="Export data file (JSON)" icon="download" tone="secondary" onPress={exportData} /><Text style={[styles.restoreNote, { color: colors.mutedForeground }]}>PDF is for viewing and sharing. JSON preserves the structured data for future restore.</Text>
    <SectionTitle title="Data safety" /><Button label="Clear local data" icon="trash-2" tone="danger" onPress={clearData} />
  </KeyboardAwareScrollViewCompat>;
}

const styles = StyleSheet.create({
  root: { flex: 1 }, content: { paddingHorizontal: 16, paddingTop: 18, paddingBottom: 50, width: '100%', maxWidth: 640, alignSelf: 'center' }, title: { fontSize: 25, fontWeight: '800', letterSpacing: -0.9, marginBottom: 5 }, subtitle: { fontSize: 12, lineHeight: 18, marginBottom: 22 }, helper: { fontSize: 11, lineHeight: 17, marginTop: -4, marginBottom: 14 }, restoreNote: { fontSize: 10, lineHeight: 16, marginTop: 10, marginBottom: 24 },
});