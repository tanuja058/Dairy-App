import { Alert, Linking } from 'react-native';
import { AppData, Customer, money, quantity } from '@/lib/milk-store';

export function buildDuePaymentMessage(customer: Customer, data: AppData) {
  const month = new Date().toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  const entries = data.entries.filter((entry) => entry.customerId === customer.id);
  const payments = data.payments.filter((payment) => payment.customerId === customer.id);
  const milkQuantity = entries.reduce((sum, entry) => sum + quantity(entry), 0);
  const milkAmount = entries.reduce((sum, entry) => sum + entry.amount, 0);
  const paidAmount = payments.reduce((sum, payment) => sum + payment.amount, 0);
  const outstanding = Math.max(0, milkAmount - paidAmount);

  return `Hello ${customer.name},

Your milk account summary for ${month}:
Total Milk: ${milkQuantity.toFixed(2)} L
Milk Amount: ${money(milkAmount)}
Payment Received: ${money(paidAmount)}
Outstanding Amount: ${money(outstanding)}

Kindly make the pending payment at your convenience.

Thank you,
${data.settings.businessName}`;
}

export async function sendWhatsAppMessage(phone: string, message: string) {
  const digits = phone.replace(/\D/g, '');
  const formattedPhone = digits.length === 10 ? `91${digits}` : digits;
  const url = `whatsapp://send?phone=${formattedPhone}&text=${encodeURIComponent(message)}`;
  const webUrl = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
  try {
    if (await Linking.canOpenURL(url)) {
      await Linking.openURL(url);
    } else {
      await Linking.openURL(webUrl);
    }
  } catch {
    Alert.alert('WhatsApp unavailable', 'Install WhatsApp or check the customer phone number, then try again.');
  }
}