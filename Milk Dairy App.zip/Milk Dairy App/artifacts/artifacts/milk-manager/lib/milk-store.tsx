import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type Shift = 'Morning' | 'Evening';
export type CustomerStatus = 'Active' | 'Inactive';
export type PaymentMethod = 'Cash' | 'UPI' | 'Bank transfer' | 'Other';

export interface RateRow {
  fat: number;
  rate: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  status: CustomerStatus;
  rates: RateRow[];
  createdAt: string;
}

export interface MilkEntry {
  id: string;
  customerId: string;
  date: string;
  shift: Shift;
  liters: number;
  ml: number;
  fat: number;
  rate: number;
  amount: number;
  remarks: string;
}

export interface Payment {
  id: string;
  customerId: string;
  date: string;
  amount: number;
  method: PaymentMethod;
  note: string;
}

export interface Settings {
  businessName: string;
  businessPhone: string;
  businessAddress: string;
  upiId: string;
}

export interface AppData {
  customers: Customer[];
  entries: MilkEntry[];
  payments: Payment[];
  settings: Settings;
}

const STORAGE_KEY = 'milk-manager-data-v1';
const makeId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
export const todayKey = () => new Date().toISOString().slice(0, 10);
export const formatDate = (date: string) => {
  const parsed = new Date(`${date}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};
export const money = (value: number) => `₹${Math.round(value).toLocaleString('en-IN')}`;
export const quantity = (entry: Pick<MilkEntry, 'liters' | 'ml'>) => entry.liters + entry.ml / 1000;

const demoRates: RateRow[] = [
  { fat: 3, rate: 40 }, { fat: 3.5, rate: 42.5 }, { fat: 4, rate: 45 },
  { fat: 4.5, rate: 47.5 }, { fat: 5, rate: 50 }, { fat: 5.5, rate: 52.5 },
];

const initialData: AppData = {
  customers: [
    { id: 'cust-1', name: 'Ananda Pandit', phone: '9876543210', address: 'Nashik Road', status: 'Active', rates: demoRates, createdAt: todayKey() },
    { id: 'cust-2', name: 'Meera Dairy Farm', phone: '9822014567', address: 'Panchavati', status: 'Active', rates: demoRates.map((row) => ({ ...row, rate: row.rate + 1 })), createdAt: todayKey() },
    { id: 'cust-3', name: 'Ravi Shinde', phone: '9765432108', address: 'Deolali', status: 'Inactive', rates: demoRates, createdAt: todayKey() },
  ],
  entries: [
    { id: 'entry-1', customerId: 'cust-1', date: todayKey(), shift: 'Morning', liters: 5, ml: 500, fat: 4.5, rate: 47.5, amount: 261.25, remarks: '' },
    { id: 'entry-2', customerId: 'cust-2', date: todayKey(), shift: 'Morning', liters: 8, ml: 0, fat: 4, rate: 46, amount: 368, remarks: '' },
    { id: 'entry-3', customerId: 'cust-1', date: todayKey(), shift: 'Evening', liters: 4, ml: 750, fat: 4.2, rate: 46, amount: 218.5, remarks: '' },
  ],
  payments: [
    { id: 'payment-1', customerId: 'cust-1', date: todayKey(), amount: 500, method: 'UPI', note: 'Weekly payment' },
  ],
  settings: { businessName: 'Green Meadow Dairy', businessPhone: '', businessAddress: 'Nashik, Maharashtra', upiId: '' },
};

export function interpolateRate(rates: RateRow[], fat: number) {
  if (!rates.length || Number.isNaN(fat)) return 0;
  const sorted = [...rates].sort((a, b) => a.fat - b.fat);
  if (fat <= sorted[0].fat) return sorted[0].rate;
  if (fat >= sorted[sorted.length - 1].fat) return sorted[sorted.length - 1].rate;
  const exact = sorted.find((row) => Math.abs(row.fat - fat) < 0.001);
  if (exact) return exact.rate;
  const upperIndex = sorted.findIndex((row) => row.fat > fat);
  const lower = sorted[upperIndex - 1];
  const upper = sorted[upperIndex];
  const ratio = (fat - lower.fat) / (upper.fat - lower.fat);
  return Math.round((lower.rate + ratio * (upper.rate - lower.rate)) * 100) / 100;
}

interface MilkContextValue {
  data: AppData;
  hydrated: boolean;
  addCustomer: (input: Omit<Customer, 'id' | 'createdAt'>) => void;
  updateCustomer: (id: string, input: Partial<Customer>) => void;
  addEntry: (input: Omit<MilkEntry, 'id' | 'rate' | 'amount'>) => boolean;
  updateEntry: (id: string, input: Omit<MilkEntry, 'id' | 'rate' | 'amount'>) => boolean;
  deleteEntry: (id: string) => void;
  addPayment: (input: Omit<Payment, 'id'>) => void;
  updateSettings: (input: Partial<Settings>) => void;
  getRate: (customerId: string, fat: number) => number;
  customerBalance: (customerId: string) => number;
}

const MilkContext = createContext<MilkContextValue | null>(null);

export function MilkProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(initialData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored) {
        try { setData(JSON.parse(stored) as AppData); } catch { setData(initialData); }
      }
      setHydrated(true);
    });
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, hydrated]);

  const value = useMemo<MilkContextValue>(() => {
    const addCustomer = (input: Omit<Customer, 'id' | 'createdAt'>) =>
      setData((current) => ({ ...current, customers: [{ ...input, id: makeId('customer'), createdAt: todayKey() }, ...current.customers] }));
    const updateCustomer = (id: string, input: Partial<Customer>) =>
      setData((current) => ({ ...current, customers: current.customers.map((customer) => customer.id === id ? { ...customer, ...input } : customer) }));
    const getRate = (customerId: string, fat: number) => interpolateRate(data.customers.find((customer) => customer.id === customerId)?.rates ?? [], fat);
    const addEntry = (input: Omit<MilkEntry, 'id' | 'rate' | 'amount'>) => {
      if (data.entries.some((entry) => entry.customerId === input.customerId && entry.date === input.date && entry.shift === input.shift)) return false;
      const rate = getRate(input.customerId, input.fat);
      const amount = Math.round(quantity(input) * rate * 100) / 100;
      setData((current) => ({ ...current, entries: [{ ...input, id: makeId('entry'), rate, amount }, ...current.entries] }));
      return true;
    };
    const updateEntry = (id: string, input: Omit<MilkEntry, 'id' | 'rate' | 'amount'>) => {
      if (data.entries.some((entry) => entry.id !== id && entry.customerId === input.customerId && entry.date === input.date && entry.shift === input.shift)) return false;
      const rate = getRate(input.customerId, input.fat);
      const amount = Math.round(quantity(input) * rate * 100) / 100;
      setData((current) => ({ ...current, entries: current.entries.map((entry) => entry.id === id ? { ...input, id, rate, amount } : entry) }));
      return true;
    };
    const deleteEntry = (id: string) => setData((current) => ({ ...current, entries: current.entries.filter((entry) => entry.id !== id) }));
    const addPayment = (input: Omit<Payment, 'id'>) =>
      setData((current) => ({ ...current, payments: [{ ...input, id: makeId('payment') }, ...current.payments] }));
    const updateSettings = (input: Partial<Settings>) => setData((current) => ({ ...current, settings: { ...current.settings, ...input } }));
    const customerBalance = (customerId: string) =>
      data.entries.filter((entry) => entry.customerId === customerId).reduce((sum, entry) => sum + entry.amount, 0) -
      data.payments.filter((payment) => payment.customerId === customerId).reduce((sum, payment) => sum + payment.amount, 0);
    return { data, hydrated, addCustomer, updateCustomer, addEntry, updateEntry, deleteEntry, addPayment, updateSettings, getRate, customerBalance };
  }, [data, hydrated]);

  return <MilkContext.Provider value={value}>{children}</MilkContext.Provider>;
}

export function useMilk() {
  const value = useContext(MilkContext);
  if (!value) throw new Error('useMilk must be used inside MilkProvider');
  return value;
}