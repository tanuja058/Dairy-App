/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#183229',
    tint: '#176B4D',

    background: '#F5F7F2',
    foreground: '#183229',

    card: '#FFFFFF',
    cardForeground: '#183229',

    primary: '#176B4D',
    primaryForeground: '#ffffff',

    secondary: '#E9F0E9',
    secondaryForeground: '#24543F',

    muted: '#EEF2EC',
    mutedForeground: '#708078',

    accent: '#F4E7C8',
    accentForeground: '#7C5C19',

    destructive: '#C84C4C',
    destructiveForeground: '#ffffff',

    border: '#DDE6DC',
    input: '#D4DFD4',
  },

  radius: 16,
};

export default colors;
